<?php
/**
 * South African states
 */
$states['ZA'] = array(
  'EC'  => _x('Eastern Cape', 'ui', 'memberpress'),
  'FS'  => _x('Free State', 'ui', 'memberpress'),
  'GP'  => _x('Gauteng', 'ui', 'memberpress'),
  'KZN' => _x('KwaZulu-Natal', 'ui', 'memberpress'),
  'LP'  => _x('Limpopo', 'ui', 'memberpress'),
  'MP'  => _x('Mpumalanga', 'ui', 'memberpress'),
  'NC'  => _x('Northern Cape', 'ui', 'memberpress'),
  'NW'  => _x('North West', 'ui', 'memberpress'),
  'WC'  => _x('Western Cape', 'ui', 'memberpress')
);

