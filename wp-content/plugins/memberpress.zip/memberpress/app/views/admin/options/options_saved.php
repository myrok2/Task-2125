<?php if(!defined('ABSPATH')) {die('You are not allowed to call this page directly.');} ?>
<div class="updated"><p><strong><?php _e('Options saved.', 'memberpress'); ?></strong></p></div>
