<?php if(!defined('ABSPATH')) {die('You are not allowed to call this page directly.');} ?>

<h3><?php _ex('An Unknown Error Occurred', 'ui', 'memberpress'); ?></h3>
