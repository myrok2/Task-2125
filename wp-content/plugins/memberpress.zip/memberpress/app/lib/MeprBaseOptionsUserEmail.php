<?php
if(!defined('ABSPATH')) {die('You are not allowed to call this page directly.');}

abstract class MeprBaseOptionsUserEmail extends MeprBaseOptionsEmail {
  // we do nothing ... this class is purely for taxonomy
}

